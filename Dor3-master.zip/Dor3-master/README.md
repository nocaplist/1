# Dor3
Tembak Kuota Three
- Cek poin bonstri di my.tri.co.id
- Syarat harus memiliki poin bonstri minimal 150 poin
- Redeem voucher kuota 1gb,2gb atau 3gb (secukupnya poinmu) di bonstri.tri.co.id

# Instalasi (termux)
- Buka termux masukan command "pkg install php php-curl git && git clone https://github.com/im-hanzou/Dor3.git && cd Dor3 && php dor.php" (tanpa tanda petik)

# Penggunaaan
- Masukkan No Telepon : 089xxx (lalu akan mendapatkan kode OTP)
- Masukkan OTP : xxxxxx (kode OTP dari sms)

NB : JANGAN MARUK!  RESIKO DITANGGUNG PENGGUNA!
